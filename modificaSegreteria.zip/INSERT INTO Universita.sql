INSERT INTO Universita.Indirizzo (cap, citta)
VALUES 
  ('00100', 'Roma'),
  ('00123', 'Milano'),
  ('00145', 'Napoli');

/**/

INSERT INTO Universita.Segreteria (nome, cognome, data_di_nascita, telefono, email, via, cap, civico, password)
VALUES 
  ('Anna', 'Bianchi', '1987-04-12', '5551112222', 'anna.bianchi@email.com', 'Via Roma 7', '00100', 'G7', 'segreteria1'),
  ('Marco', 'Rizzo', '1985-09-08', '4443335555', 'marco.rizzo@email.com', 'Via Garibaldi 8', '00123', 'H8', 'segreteria2'),
  ('Elena', 'Mancini', '1989-02-25', '7778880000', 'elena.mancini@email.com', 'Via Venezia 9', '00145', 'I9', 'segreteria3');

/**/


INSERT INTO Universita.Docente (nome, cognome, data_di_nascita, telefono, email, via, cap, civico, password)
VALUES 
  ('Mario', 'Rossi', '1990-05-15', '1234567890', 'mario.rossi@email.com', 'Via Roma 1', '00100', 'A1', 'password123'),
  ('Luigi', 'Verdi', '1985-08-22', '9876543210', 'luigi.verdi@email.com', 'Via Garibaldi 2', '00123', 'B2', 'securepass'),
  ('Paola', 'Bianchi', '1988-03-10', '5554443333', 'paola.bianchi@email.com', 'Via Venezia 3', '00145', 'C3', 'mypassword');


/**/

INSERT INTO Universita.corso_di_laurea (tipologia, id_docente, nome)
VALUES 
  (true, 'c29afd', 'Ingegneria Informatica'),
  (false, '5da767', 'Scienze della Comunicazione'),
  (true, '245437', 'Medicina');

/**/

INSERT INTO Universita.insegnamento (anno, id_docente_responsabile, nome)
VALUES 
  (1, 'c29afd', 'Programmazione Java'),
  (2, '5da767', 'Comunicazione Organizzativa'),
  (3, '245437', 'Anatomia Umana');

/**/

INSERT INTO universita.programma (id_insegnamento, id_corso_di_laurea)
VALUES 
  (1, 1),
  (2, 2),
  (3, 3);

/**/

INSERT INTO Universita.Studente (nome, cognome, data_di_nascita, telefono, email, via, cap, civico, id_corso, password)
VALUES 
  ('Giuseppe', 'Ferrari', '1998-01-25', '3332221111', 'giuseppe.ferrari@email.com', 'Via Milano 4', '00100', 'D4', 1, 'studentpass1'),
  ('Laura', 'Mancini', '1999-07-14', '7778889999', 'laura.mancini@email.com', 'Via Firenze 5', '00123', 'E5', 2, 'studentpass2'),
  ('Giovanni', 'Russo', '1997-11-30', '4445556666', 'giovanni.russo@email.com', 'Via Napoli 6', '00145', 'F6', 3, 'studentpass3');


/**/

INSERT INTO universita.propedeutico (id_insegnamento1, id_insegnamento2)
VALUES 
  (1, 2),
  (2, 3),
  (3, 1);

/**/

INSERT INTO Universita.esame (data, ora, tipologia, id_insegnamento, id_docente)
VALUES 
  ('2023-10-15', '14:00:00', 'Scritto', 1, 'c29afd'),
  ('2023-11-20', '10:30:00', 'Orale', 2, '5da767'),
  ('2023-12-05', '15:45:00', 'Scritto', 3, '245437');


/**/



INSERT INTO universita.incarico (id_docente, id_insegnamento)
VALUES 
  ('c29afd', 1),
  ('5da767', 2),
  ('245437', 3);


/**/

INSERT INTO universita.prenotante (matricola_studente, id_esame)
VALUES 
  ('e309e4', 1),
  ('784520', 2),
  ('6ab471', 3);

/**/

INSERT INTO Universita.trascrizione (id_esame, id_carriera, voto)
VALUES 
  (1, 7, 28),
  (2, 8, 23),
  (3, 9, 30);


/**/
/* Inserimento dati nella tabella Indirizzo */
INSERT INTO Universita.Indirizzo (cap, citta)
VALUES
    ('00100', 'Roma'),
    ('20100', 'Milano'),
    ('40100', 'Bologna');

/* Inserimento dati nella tabella Docente */
INSERT INTO Universita.Docente (nome, cognome, data_di_nascita, telefono, email, via, cap, civico, password)
VALUES
    ('Mario', 'Rossi', '1980-05-15', '1234567890', 'mario.rossi@example.com', 'Via Roma', '00100', '10', 'password123'),
    ('Laura', 'Bianchi', '1975-08-20', '9876543210', 'laura.bianchi@example.com', 'Via Milano', '20100', '5', 'securepass'),
    ('Luigi', 'Verdi', '1982-02-10', '5555555555', 'luigi.verdi@example.com', 'Via Bologna', '40100', '8', 'secret123');

/* Inserimento dati nella tabella Corso di Laurea */
INSERT INTO Universita.corso_di_laurea (tipologia, id_docente, nome)
VALUES
    (true, 'ef6758', 'Ingegneria Informatica'),
    (false, 'b198a7', 'Scienze Politiche'),
    (true, '839895', 'Economia Aziendale');

/* Inserimento dati nella tabella Studente */
INSERT INTO Universita.Studente (nome, cognome, data_di_nascita, telefono, email, via, cap, civico, id_corso, password)
VALUES
    ('Marco', 'Verdi', '2000-03-20', '1111111111', 'marco.verdi@example.com', 'Via Roma', '00100', '15', 1, 'studentpass'),
    ('Elena', 'Ricci', '1999-07-10', '2222222222', 'elena.ricci@example.com', 'Via Milano', '20100', '12', 2, 'pass123'),
    ('Giuseppe', 'Gallo', '2001-01-05', '3333333333', 'giuseppe.gallo@example.com', 'Via Bologna', '40100', '20', 4, 'password456');

/* Inserimento dati nella tabella Segreteria */
INSERT INTO Universita.Segreteria (nome, cognome, data_di_nascita, telefono, email, via, cap, civico, password)
VALUES
    ('Anna', 'Bianchi', '1970-12-05', '4444444444', 'anna.bianchi@example.com', 'Via Roma', '00100', '25', 'secretpass'),
    ('Giovanni', 'Ferrari', '1965-04-30', '5555555555', 'giovanni.ferrari@example.com', 'Via Milano', '20100', '3', 'admin123');

/* Inserimento dati nella tabella Insegnamento */
INSERT INTO universita.insegnamento (anno, id_docente_responsabile, nome)
VALUES
    (1, 'ef6758', 'Matematica'),
    (2, 'b198a7', 'Storia dell''Arte'),
    (2, 'b198a7', 'Analisi 2'),
    (3, 'ef6758', 'Economia');

/* Inserimento dati nella tabella programma (associazione insegnamenti ai corsi di laurea) */
INSERT INTO universita.programma (id_insegnamento, id_corso_di_laurea)
VALUES
    (9, 1),
    (10, 2),
    (11, 1),
    (12, 4);

/* Inserimento dati nella tabella Propedeutico (insegnamenti propedeutici) */
INSERT INTO universita.propedeutico (id_insegnamento1, id_insegnamento2)
VALUES
    (9, 11);

/* Inserimento dati nella tabella Esame */
INSERT INTO Universita.esame (id_insegnamento, data, ora, tipologia, id_docente, nome_esame)
VALUES
    (9, '2023-05-10', '09:00:00', 'Scritto', 'ef6758', 'Esame di Matematica'),
    (10, '2023-06-15', '14:30:00', 'Orale', 'b198a7', 'Esame di Storia dell''Arte'),
    (11, '2023-06-14', '14:30:00', 'Orale', 'b198a7', 'Esame di Analisi'),
    (12, '2023-07-20', '10:00:00', 'Scritto', 'ef6758', 'Esame di Economia');

/* Inserimento dati nella tabella Trascrizione (risultati esami studenti) */
INSERT INTO Universita.trascrizione (id_insegnamento, data, id_carriera, voto, esito)
VALUES
    (1, '2023-05-10', 1, 25, true),
    (2, '2023-06-15', 2, 28, true),
    (3, '2023-07-20', 3, 22, true);
